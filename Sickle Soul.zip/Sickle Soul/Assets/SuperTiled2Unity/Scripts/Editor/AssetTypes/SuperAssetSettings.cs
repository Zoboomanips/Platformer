﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SuperTiled2Unity.Editor
{
    // Used to tag assets specific to SuperTiled2Unity
    public class SuperAssetSettings : SuperAsset
    {
    }
}
