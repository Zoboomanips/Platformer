﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace SuperTiled2Unity
{
    public class SuperObjectLayer : SuperLayer
    {
        [ReadOnly]
        public Color m_Color;
    }
}
