﻿using UnityEngine;

namespace SuperTiled2Unity
{
    public class ReadOnlyAttribute : PropertyAttribute
    {
    }
}
